-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 09-08-2016 a las 06:01:39
-- Versión del servidor: 5.6.21
-- Versión de PHP: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `road_local`
--
CREATE DATABASE IF NOT EXISTS `road_local` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `road_local`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `boletos`
--

CREATE TABLE IF NOT EXISTS `boletos` (
`cve` int(4) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `guia` int(4) NOT NULL,
  `unidad` int(4) NOT NULL,
  `no_eco` int(4) NOT NULL,
  `costo` int(4) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `usuario` int(4) NOT NULL,
  `estatus` tinyint(1) NOT NULL,
  `usucan` int(4) NOT NULL,
  `fechacan` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `costo_boletos`
--

CREATE TABLE IF NOT EXISTS `costo_boletos` (
`cve` int(4) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `costo` decimal(10,2) NOT NULL,
  `estatus` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `guia`
--

CREATE TABLE IF NOT EXISTS `guia` (
`cve` int(4) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL,
  `unidad` int(4) NOT NULL,
  `no_eco` int(4) NOT NULL,
  `usuario` int(4) NOT NULL,
  `fecha_fin` date NOT NULL,
  `hora_fin` time NOT NULL,
  `usuario_fin` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `taquilla`
--

CREATE TABLE IF NOT EXISTS `taquilla` (
  `cve` int(4) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `tipo_impresora` tinyint(1) NOT NULL,
  `nombre_impresora` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `unidades`
--

CREATE TABLE IF NOT EXISTS `unidades` (
  `cve` int(4) NOT NULL,
  `no_eco` int(4) NOT NULL,
  `estatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `cve` int(4) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tipo_taquilla` tinyint(1) NOT NULL,
  `estatus` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `boletos`
--
ALTER TABLE `boletos`
 ADD PRIMARY KEY (`cve`);

--
-- Indices de la tabla `costo_boletos`
--
ALTER TABLE `costo_boletos`
 ADD PRIMARY KEY (`cve`);

--
-- Indices de la tabla `guia`
--
ALTER TABLE `guia`
 ADD PRIMARY KEY (`cve`);

--
-- Indices de la tabla `taquilla`
--
ALTER TABLE `taquilla`
 ADD PRIMARY KEY (`cve`);

--
-- Indices de la tabla `unidades`
--
ALTER TABLE `unidades`
 ADD PRIMARY KEY (`cve`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
 ADD PRIMARY KEY (`cve`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `boletos`
--
ALTER TABLE `boletos`
MODIFY `cve` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT de la tabla `costo_boletos`
--
ALTER TABLE `costo_boletos`
MODIFY `cve` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
--
-- AUTO_INCREMENT de la tabla `guia`
--
ALTER TABLE `guia`
MODIFY `cve` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
